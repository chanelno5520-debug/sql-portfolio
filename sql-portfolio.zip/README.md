# SQL Portfolio (Beginner → Practical)

這個作品集整理我在 SQL 入門階段的練習，並以 **QA / 資料驗證** 的角度重新包裝：
- 不只寫得出 SQL，而是能解釋「為什麼這樣查」與「結果怎麼判讀」
- 重視可讀性（AS 別名）、可交付性（結果能直接提供給他人）

## Skills
- SELECT / FROM / LIMIT
- DISTINCT
- AS（欄位別名與可讀性）
- 基礎資料預覽與查詢結果解讀（QA 角度）

## Project Structure
- `hahow-sql-fifty/`: 入門練習精選（由 exercises_colab.ipynb 整理）

## How to Use
使用 SQLiteStudio / DB Browser for SQLite / 任意 SQL IDE 皆可。  
每題 `.sql` 檔案內含：
- 題目（Problem）
- 情境（Scenario）
- SQL 解法（Query）
- 判讀方式（How to Interpret）
